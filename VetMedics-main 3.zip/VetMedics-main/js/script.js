const GOOGLE_SCRIPT_URL =
"https://script.google.com/macros/s/AKfycbwvEOQK3rOoVpOLjqZTXxZiITAMlEcsfPARyZRJar7YpS_p4Yve9hBHKutTUA26RUfv4w/exec";

// =========================
// Vet Medics Pet Clinic
// script.js
// =========================

// Smooth scroll for menu links
document.querySelectorAll('nav a').forEach(link => {
    link.addEventListener('click', function(e) {
        const target = document.querySelector(this.getAttribute('href'));

        if (target) {
            e.preventDefault();
            target.scrollIntoView({
                behavior: 'smooth'
            });
        }
    });
});

// Fade animation on scroll
const cards = document.querySelectorAll(".card");

window.addEventListener("scroll", () => {
    cards.forEach(card => {
        const top = card.getBoundingClientRect().top;
        if (top < window.innerHeight - 80) {
            card.style.opacity = "1";
            card.style.transform = "translateY(0)";
        }
    });
});

cards.forEach(card => {
    card.style.opacity = "0";
    card.style.transform = "translateY(50px)";
    card.style.transition = "0.6s ease";
});

// Floating WhatsApp Button
const whatsapp = document.createElement("a");
whatsapp.href = "https://wa.me/919772333320";
whatsapp.target = "_blank";
whatsapp.innerHTML = "💬";
whatsapp.className = "floating-whatsapp";

document.body.appendChild(whatsapp);

// Back To Top Button
const topBtn = document.createElement("button");
topBtn.innerHTML = "⬆";
topBtn.className = "top-btn";
document.body.appendChild(topBtn);

window.addEventListener("scroll", () => {
    if (window.scrollY > 300) {
        topBtn.style.display = "block";
    } else {
        topBtn.style.display = "none";
    }
});

topBtn.onclick = () => {
    window.scrollTo({
        top: 0,
        behavior: "smooth"
    });
};

// ================= SEARCH SERVICES =================

const searchInput = document.getElementById('searchInput');
const searchBtn = document.getElementById('searchBtn');
const serviceCards = document.querySelectorAll('.service-card');

function searchServices() {

    const value = searchInput.value.trim().toLowerCase();

    let found = 0;

    serviceCards.forEach(card => {

        const text = card.innerText.toLowerCase();

        if (value === '' || text.includes(value)) {
            card.style.display = '';
            found++;
        } else {
            card.style.display = 'none';
        }

    });

    let noResult = document.getElementById('noSearchResult');

    if (!noResult) {

        noResult = document.createElement('p');

        noResult.id = 'noSearchResult';

        noResult.textContent =
            'No matching service found. Try Vaccination, Grooming or Surgery.';

        noResult.style.cssText =
            'display:none;text-align:center;margin:25px 0;color:#666;font-weight:500;';

        document.querySelector('.service-grid').after(noResult);
    }

    if (value !== '' && found === 0) {
        noResult.style.display = 'block';
    } else {
        noResult.style.display = 'none';
    }

    if (value !== '') {
        document.getElementById('services').scrollIntoView({
            behavior: 'smooth'
        });
    }
}

if (searchBtn) {
    searchBtn.addEventListener('click', searchServices);
}

if (searchInput) {

    searchInput.addEventListener('input', searchServices);

    searchInput.addEventListener('keydown', function(e) {

        if (e.key === 'Enter') {
            searchServices();
        }

    });
}

// ================= VACCINATION PACKAGES =================

function openVaccinationPackages() {

    const modal = document.getElementById("vaccinationPackages");

    modal.style.display = "flex";

    document.body.style.overflow = "hidden";
}


function closeVaccinationPackages() {

    const modal = document.getElementById("vaccinationPackages");

    modal.style.display = "none";

    document.body.style.overflow = "auto";
}


// ================= PACKAGE DETAILS =================

function showPackageDetails(packageType) {

    const detailModal = document.getElementById("packageDetails");

    const content = document.getElementById("packageDetailContent");

    let html = "";


    if (packageType === "puppy") {

        html = `
            <h2>🐶 Puppy Vaccination Package</h2>

            <h3>Package Includes</h3>

            <ul>
                <li>Core puppy vaccination schedule</li>
                <li>Age-wise vaccination guidance</li>
                <li>Veterinary consultation</li>
                <li>Vaccination record update</li>
                <li>Follow-up vaccination reminder</li>
            </ul>

            <h3>Recommended For</h3>

            <p>
                Puppies requiring their initial vaccination series.
            </p>

            <div class="package-price">
                Starting from ₹3999
            </div>

        <a href="appointment.html" class="book-now-btn">
    Book Now
</a>
        `;

    }


    else if (packageType === "adultDog") {

        html = `
            <h2>🐕 Adult Dog Vaccination Package</h2>

            <h3>Package Includes</h3>

            <ul>
                <li>Annual vaccination consultation</li>
                <li>Required booster vaccination</li>
                <li>Veterinary health assessment</li>
                <li>Vaccination record update</li>
                <li>Next due-date reminder</li>
            </ul>

            <h3>Recommended For</h3>

            <p>
                Adult dogs requiring regular booster vaccination.
            </p>

            <div class="package-price">
                Starting from ₹1599
            </div>

         <a href="appointment.html" class="book-now-btn">
    Book Now
</a>
        `;

    }


    else if (packageType === "kitten") {

        html = `
            <h2>🐱 Kitten Vaccination Package</h2>

            <h3>Package Includes</h3>

            <ul>
                <li>Kitten vaccination schedule</li>
                <li>Age-wise vaccination guidance</li>
                <li>Veterinary consultation</li>
                <li>Vaccination record update</li>
                <li>Follow-up reminder</li>
            </ul>

            <h3>Recommended For</h3>

            <p>
                Kittens requiring their initial vaccination series.
            </p>

            <div class="package-price">
                Starting from ₹4399
            </div>

        <a href="appointment.html" class="book-now-btn">
    Book Now
</a>
        `;

    }


    else if (packageType === "adultCat") {

        html = `
            <h2>🐈 Adult Cat Vaccination Package</h2>

            <h3>Package Includes</h3>

            <ul>
                <li>Annual vaccination consultation</li>
                <li>Required booster vaccination</li>
                <li>Veterinary health assessment</li>
                <li>Vaccination record update</li>
                <li>Next due-date reminder</li>
            </ul>

            <h3>Recommended For</h3>

            <p>
                Adult cats requiring regular vaccination and boosters.
            </p>

            <div class="package-price">
                Starting from ₹1799
            </div>

        <a href="appointment.html" class="book-now-btn">
    Book Now
</a> 
        `;

    }


    content.innerHTML = html;

    detailModal.style.display = "flex";

}


function closePackageDetails() {

    const modal = document.getElementById("packageDetails");

    modal.style.display = "none";

    document.body.style.overflow = "auto";
}


// Close when clicking outside the box

document.getElementById("vaccinationPackages").addEventListener("click", function(e) {

    if (e.target === this) {
        closeVaccinationPackages();
    }

});


document.getElementById("packageDetails").addEventListener("click", function(e) {

    if (e.target === this) {
        closePackageDetails();
    }

});

// ================= TELECONSULTATION PACKAGES =================

function openTeleconsultationPackages() {

    const modal = document.getElementById("teleconsultationPackages");

    modal.style.display = "flex";

    document.body.style.overflow = "hidden";
}


function closeTeleconsultationPackages() {

    const modal = document.getElementById("teleconsultationPackages");

    modal.style.display = "none";

    document.body.style.overflow = "auto";
}


// ================= TELECONSULTATION DETAILS =================

function showTeleconsultationDetails(type) {

    const detailModal =
        document.getElementById("teleconsultationDetails");

    const content =
        document.getElementById("teleconsultationDetailContent");

    let html = "";


    if (type === "video") {

        html = `
            <h2>📹 Video Consultation</h2>

            <h3>Consultation Includes</h3>

            <ul>
                <li>Live video consultation with veterinarian</li>
                <li>Discussion of your pet's symptoms</li>
                <li>Basic health guidance</li>
                <li>Medication and care guidance</li>
                <li>Further treatment advice if required</li>
            </ul>

            <h3>Recommended For</h3>

            <p>
                Pet owners who want to discuss their pet's health
                with a veterinarian through a video call.
            </p>

            <div class="package-price">
                Price: ₹199
            </div>

           <a href="appointment.html" class="book-now-btn">
    Book Now
</a> 
        `;

    }


    else if (type === "phone") {

        html = `
            <h2>📞 Phone Consultation</h2>

            <h3>Consultation Includes</h3>

            <ul>
                <li>Direct phone consultation with veterinarian</li>
                <li>Discussion of health concerns</li>
                <li>General veterinary advice</li>
                <li>Medication and care guidance</li>
                <li>Further treatment advice if required</li>
            </ul>

            <h3>Recommended For</h3>

            <p>
                Pet owners who prefer a convenient veterinary
                consultation over the phone.
            </p>

            <div class="package-price">
                Price: ₹99
            </div>

<a href="appointment.html" class="book-now-btn">
    Book Now
</a>
        `;

    }


    else if (type === "followup") {

        html = `
            <h2>🔄 Follow-up Consultation</h2>

            <h3>Consultation Includes</h3>

            <ul>
                <li>Follow-up with the veterinarian within 3 days</li>
                <li>Review of treatment progress</li>
                <li>Discussion of recovery</li>
                <li>Medication guidance</li>
                <li>Further care recommendations</li>
            </ul>

            <h3>Recommended For</h3>

            <p>
                Pets who have already had a consultation or treatment
                and require follow-up advice.
            </p>

            <div class="package-price">
                Price: ₹0
            </div>

      <a href="appointment.html" class="book-now-btn">
    Book Now
</a>      
        `;

    }


    content.innerHTML = html;

    detailModal.style.display = "flex";

    document.body.style.overflow = "hidden";
}


function closeTeleconsultationDetails() {

    const modal =
        document.getElementById("teleconsultationDetails");

    modal.style.display = "none";

    document.body.style.overflow = "auto";
}


// Close Teleconsultation package overlay
document.getElementById("teleconsultationPackages")
    .addEventListener("click", function(e) {

        if (e.target === this) {
            closeTeleconsultationPackages();
        }

    });


// Close Teleconsultation details overlay
document.getElementById("teleconsultationDetails")
    .addEventListener("click", function(e) {

        if (e.target === this) {
            closeTeleconsultationDetails();
        }

    });

// ================= HOME VISIT PACKAGES =================

function openHomeVisitPackages() {

    const modal =
        document.getElementById("homeVisitPackages");

    modal.style.display = "flex";

    document.body.style.overflow = "hidden";
}


function closeHomeVisitPackages() {

    const modal =
        document.getElementById("homeVisitPackages");

    modal.style.display = "none";

    document.body.style.overflow = "auto";
}


// ================= HOME VISIT DETAILS =================

function showHomeVisitDetails(type) {

    const detailModal =
        document.getElementById("homeVisitDetails");

    const content =
        document.getElementById("homeVisitDetailContent");

    let html = "";


    // GENERAL HOME VISIT

    if (type === "general") {

        html = `
            <h2>🏠 General Home Visit</h2>

            <h3>Service Includes</h3>

            <ul>
                <li>Veterinary consultation at your home</li>
                <li>Advanced clinical examination</li>
                <li>Advanced Diagnostics</li>
                <li>Discussion of your pet's health concerns</li>
                <li>Medication and care guidance</li>
                <li>Further treatment recommendations if required</li>
            </ul>

            <h3>Suitable For</h3>

            <p>
                Pets requiring veterinary consultation or basic
                examination at home.
            </p>

            <div class="package-price">
           Consultaion Charges : ₹699 (Upto 8PM)
           Emergency Charges : ₹999 (8PM-8AM)
           
            </div>

           <a href="appointment.html" class="book-now-btn">
    Book Now
</a>
         `;

    }


    // HEALTH AND TRAVEL CERTIFICATE

    else if (type === "certificate") {

        html = `
            <h2>💉 Health And Travel Certificate</h2>

            <h3>Service Includes</h3>

            <ul>
                <li>Veterinary visit at your doorstep</li>
                <li>Vaccination status verification</li>
                <li>Digital/Printed Certificate</li>
                <li>Certificate issued after clinical examination</li>
            </ul>

            <h3>Suitable For</h3>

            <p>
                Provide valid Health and Travel Certificate for 
                Domestic/International Travel,Boarding.
            </p>

            <div class="package-price">
                Price: ₹699
            </div>

            <a href="appointment.html" class="book-now-btn">
    Book Now
</a>
        `;

    }


    content.innerHTML = html;

    detailModal.style.display = "flex";

    document.body.style.overflow = "hidden";
}


function closeHomeVisitDetails() {

    const modal =
        document.getElementById("homeVisitDetails");

    modal.style.display = "none";

    document.body.style.overflow = "auto";
}


// Close Home Visit packages by clicking outside

document.getElementById("homeVisitPackages")
    .addEventListener("click", function(e) {

        if (e.target === this) {
            closeHomeVisitPackages();
        }

    });


// Close Home Visit details by clicking outside

document.getElementById("homeVisitDetails")
    .addEventListener("click", function(e) {

        if (e.target === this) {
            closeHomeVisitDetails();
        }

    });

/* ================= PET PARENT LOCATION ================= */

document.addEventListener("DOMContentLoaded", function () {

    const locationElement = document.getElementById("user-location");

    if (!locationElement) return;

    if (!navigator.geolocation) {
        locationElement.textContent = "Location unavailable";
        return;
    }

    navigator.geolocation.getCurrentPosition(
        function (position) {

            const latitude = position.coords.latitude;
            const longitude = position.coords.longitude;

            fetch(`https://api.bigdatacloud.net/data/reverse-geocode-client?latitude=${latitude}&longitude=${longitude}&localityLanguage=en`)
    .then(response => response.json())
    .then(data => {
        const place = data.locality || data.city || data.localityInfo?.administrative?.[2]?.name || "";
        const state = data.principalSubdivision || "";

        locationElement.textContent =
            place && state ? `${place}, ${state}` : place || state || "Location unavailable";
    })
    .catch(() => {
        locationElement.textContent = "Location unavailable";
    });

        },
        function () {
            locationElement.textContent = "Location unavailable";
        }
    );
});

/* =========================================
   PET PARENT PHONE + PASSWORD LOGIN
========================================= */

function openPetParentLogin() {

    const user =
        localStorage.getItem("vetMedicsPhone");

    if (user) {

        openPetDashboard();

        return;

    }

    document.getElementById(
        "petParentLoginModal"
    ).style.display = "flex";

    document.body.style.overflow = "hidden";

    document.getElementById(
        "petParentSignup"
    ).style.display = "none";

}


function closePetParentLogin() {

    document.getElementById(
        "petParentLoginModal"
    ).style.display = "none";

    document.body.style.overflow = "auto";

}


/* =========================================
   CREATE PET PARENT ACCOUNT
========================================= */

async function createPetParentAccount() {

    const name =
        document.getElementById(
            "petParentName"
        ).value.trim();

    const phone =
        document.getElementById(
            "signupPhone"
        ).value.trim();

    const password =
        document.getElementById(
            "signupPassword"
        ).value.trim();


    if (!name) {

        showLoginMessage(
            "Please enter your name."
        );

        return;

    }


    if (!/^[0-9]{10}$/.test(phone)) {

        showLoginMessage(
            "Please enter a valid 10 digit mobile number."
        );

        return;

    }


    if (password.length < 6) {

        showLoginMessage(
            "Password must be at least 6 characters."
        );

        return;

    }


    const signupMessage =
    document.getElementById("signupMessage");

if (signupMessage) {
    signupMessage.textContent =
        "Creating account...";
}


    try {

        const response = await fetch(
            GOOGLE_SCRIPT_URL,
            {
                method: "POST",

                body: JSON.stringify({

                    action: "createAccount",

                    name: name,

                    phone: phone,

                    password: password

                })

            }
        );


        const result =
            await response.json();


if (result.success) {

    if (signupMessage) {
        signupMessage.textContent =
            "Account created successfully. Please login.";
    }

}

         else {

            if (signupMessage) {
    signupMessage.textContent =
        result.message;
}

        }


    } catch (error) {

        console.error(error);

        showLoginMessage(
            "Something went wrong. Please try again."
        );

    }

}


/* =========================================
   PET PARENT LOGIN
========================================= */

async function loginPetParent() {

    const phone =
        document.getElementById(
            "petParentPhone"
        ).value.trim();

    const password =
        document.getElementById(
            "petParentPassword"
        ).value.trim();


    if (!/^[0-9]{10}$/.test(phone)) {

        showLoginMessage(
            "Please enter a valid 10 digit mobile number."
        );

        return;

    }


    if (!password) {

        showLoginMessage(
            "Please enter your password."
        );

        return;

    }


    showLoginMessage(
        "Logging in..."
    );


    try {

        const response = await fetch(
            GOOGLE_SCRIPT_URL,
            {
                method: "POST",

                body: JSON.stringify({

                    action: "login",

                    phone: phone,

                    password: password

                })

            }
        );


        const result =
            await response.json();


        if (result.success) {

            localStorage.setItem(
                "vetMedicsPhone",
                "+91" + phone
            );

            localStorage.setItem(
                "vetMedicsParentName",
                result.name
            );


            closePetParentLogin();


            const navText =
                document.getElementById(
                    "petParentNavText"
                );

            if (navText) {

                navText.textContent =
                    "My Account";

            }


            openPetDashboard();


        } else {

            showLoginMessage(
                result.message
            );

        }


    } catch (error) {

        console.error(error);

        showLoginMessage(
            "Something went wrong. Please try again."
        );

    }

}


/* =========================================
   SHOW SIGNUP
========================================= */

function showPetParentLogin() {

    document.getElementById(
        "petParentLoginSection"
    ).style.display = "block";

    document.getElementById(
        "petParentLoginModal"
    ).style.display = "flex";

    document.getElementById(
        "petParentSignupModal"
    ).style.display = "none";

    document.body.style.overflow = "hidden";

    showLoginMessage("");

}

function showPetParentSignup() {

    document.getElementById(
        "petParentLoginModal"
    ).style.display = "none";

    document.getElementById(
        "petParentSignupModal"
    ).style.display = "flex";

    document.body.style.overflow = "hidden";

}

function closePetParentSignup() {

    document.getElementById(
        "petParentSignupModal"
    ).style.display = "none";

    document.body.style.overflow = "auto";

}

function backToPetParentLogin() {

    // Close signup
    document.getElementById(
        "petParentSignupModal"
    ).style.display = "none";

    // Open login
    document.getElementById(
        "petParentLoginModal"
    ).style.display = "flex";

    document.body.style.overflow = "hidden";

}

/* =========================================
   LOGIN MESSAGE
========================================= */

function showLoginMessage(message) {

    const element =
        document.getElementById(
            "loginMessage"
        );

    if (element) {

        element.textContent = message;

    }

}

/* =========================================
   PET PARENT DASHBOARD
========================================= */

function openPetDashboard() {

    const phone =
        localStorage.getItem(
            "vetMedicsPhone"
        );


    if (!phone) {

        openPetParentLogin();

        return;

    }


   const parentName =
    localStorage.getItem(
        "vetMedicsParentName"
    );

document.getElementById(
    "dashboardParentPhone"
).textContent = parentName || phone;


    document.getElementById(
        "petParentDashboard"
    ).style.display = "flex";


    document.body.style.overflow = "hidden";


    loadPetParentData();

}


/* Close Dashboard */

function closePetDashboard() {

    document.getElementById(
        "petParentDashboard"
    ).style.display = "none";


    document.body.style.overflow = "auto";

}


/* Logout */

function petParentLogout() {

    localStorage.removeItem(
        "vetMedicsPhone"
    );


    closePetDashboard();


    document.getElementById(
        "petParentNavText"
    ).textContent =
        "Pet Parent Login";

}


/* =========================================
   PET DATA
========================================= */

function getPetParentData() {

    const phone =
        localStorage.getItem(
            "vetMedicsPhone"
        );


    if (!phone) return null;


    const key =
        "vetMedicsData_" + phone;


    let data =
        localStorage.getItem(key);


    if (!data) {

        data = {

            pets: [],

            appointments: [],

            services: []

        };

        localStorage.setItem(
            key,
            JSON.stringify(data)
        );

    } else {

        data = JSON.parse(data);

    }


    return data;

}


/* Save Data */

function savePetParentData(data) {

    const phone =
        localStorage.getItem(
            "vetMedicsPhone"
        );


    if (!phone) return;


    const key =
        "vetMedicsData_" + phone;


    localStorage.setItem(
        key,
        JSON.stringify(data)
    );

}


/* =========================================
   LOAD DASHBOARD
========================================= */

function loadPetParentData() {

    const data =
        getPetParentData();


    if (!data) return;


    document.getElementById(
        "totalPets"
    ).textContent =
        data.pets.length;


    document.getElementById(
        "totalAppointments"
    ).textContent =
        data.appointments.length;


    document.getElementById(
        "totalServices"
    ).textContent =
        data.services.length;


    loadPets(data);

 loadOnlineAppointments(data);

  loadServices(data);

    loadAppointments(data);

}

/* =========================================
   ADD PET
========================================= */

function openAddPet() {

    document.getElementById(
        "addPetModal"
    ).style.display = "flex";

}


function closeAddPet() {

    document.getElementById(
        "addPetModal"
    ).style.display = "none";

}


/* Save Pet */

function savePet() {

    const name =
        document.getElementById(
            "petName"
        ).value.trim();


    const type =
        document.getElementById(
            "petType"
        ).value;


    const breed =
        document.getElementById(
            "petBreed"
        ).value.trim();


    const age =
        document.getElementById(
            "petAge"
        ).value;


    const gender =
        document.getElementById(
            "petGender"
        ).value;


    if (
        !name ||
        !type ||
        !breed ||
        !age ||
        !gender
    ) {

        alert("Please fill all pet details.");

        return;

    }


    const data =
        getPetParentData();


    if (!data) {

        alert("Please login first.");

        return;

    }


    data.pets.push({

        id: Date.now(),

        name: name,

        type: type,

        breed: breed,

        age: age,

        gender: gender,

        addedOn:
            new Date().toLocaleDateString()

    });


    savePetParentData(data);


    document.getElementById(
        "petName"
    ).value = "";

    document.getElementById(
        "petType"
    ).value = "";

    document.getElementById(
        "petBreed"
    ).value = "";

    document.getElementById(
        "petAge"
    ).value = "";

    document.getElementById(
        "petGender"
    ).value = "";


    closeAddPet();


    loadPetParentData();

}

/* =========================================
   LOAD PETS
========================================= */

function loadPets(data) {

    const container =
        document.getElementById(
            "myPetsList"
        );


    if (data.pets.length === 0) {

        container.innerHTML = `

            <div class="empty-pets">

                <div>🐶</div>

                <p>No pets added yet.</p>

                <small>
                    Add your pet to manage their details.
                </small>

            </div>

        `;

        return `

    <div class="pet-card">

        <div class="pet-avatar">
            ${icon}
        </div>

        <div style="flex:1;">

            <h4>
                ${pet.name}
            </h4>

            <p>
                ${pet.type} • ${pet.breed}
            </p>

            <p>
                ${pet.age} years •
                ${pet.gender}
            </p>

            <button
                onclick="deletePet(${pet.id})"
                style="
                    margin-top:10px;
                    padding:7px 12px;
                    border:none;
                    border-radius:6px;
                    cursor:pointer;
                "
            >
                🗑️ Delete Pet
            </button>

        </div>

    </div>

`;
        
        return;

    }


    container.innerHTML =
        data.pets.map(function(pet) {

            const icon =
                pet.type === "Cat"
                ? "🐱"
                : "🐶";


            return `

    <div class="pet-card">

        <div class="pet-avatar">
            ${icon}
        </div>

        <div style="flex:1;">

            <h4>
                ${pet.name}
            </h4>

            <p>
                ${pet.type} • ${pet.breed}
            </p>

            <p>
                ${pet.age} years •
                ${pet.gender}
            </p>

            <button
                onclick="deletePet(${pet.id})"
                style="
                    margin-top:10px;
                    padding:7px 12px;
                    border:none;
                    border-radius:6px;
                    cursor:pointer;
                "
            >
                🗑️ Delete Pet
            </button>

        </div>

    </div>

`;

        }).join("");

}

/* =========================================
   DELETE PET
========================================= */

function deletePet(petId) {

    const data = getPetParentData();

    if (!data) {
        alert("Please login first.");
        return;
    }

    const pet = data.pets.find(function(p) {
        return p.id === petId;
    });

    if (!pet) {
        alert("Pet not found.");
        return;
    }

    const confirmDelete = confirm(
        "Are you sure you want to delete " + pet.name + "?"
    );

    if (!confirmDelete) {
        return;
    }

    data.pets = data.pets.filter(function(p) {
        return p.id !== petId;
    });

    savePetParentData(data);

    loadPetParentData();

    alert("Pet deleted successfully.");
}

async function loadOnlineAppointments() {

    const phone =
        localStorage.getItem("vetMedicsPhone");

    if (!phone) {
        return;
    }

    try {

        const response = await fetch(
            GOOGLE_SCRIPT_URL +
            "?action=getAppointments&phone=" +
            encodeURIComponent(phone)
        );

        const result = await response.json();

        if (!result.success) {
            return;
        }

        const data = getPetParentData();

        if (!data) {
            return;
        }

        data.appointments =
            result.appointments || [];

        savePetParentData(data);

        loadAppointments(data);

        document.getElementById(
            "totalAppointments"
        ).textContent =
            data.appointments.length;

    } catch (error) {

        console.error(
            "Appointment loading error:",
            error
        );

    }

}

/* =========================================
   SERVICES
========================================= */

function loadServices(data) {

    const container =
        document.getElementById(
            "serviceHistory"
        );


    if (data.services.length === 0) {

        container.innerHTML = `

            <div class="empty-history">

                No services recorded yet.

            </div>

        `;

        return;

    }


    container.innerHTML =
        data.services.map(function(service) {

            return `

                <div class="pet-card">

                    <div class="pet-avatar">
                        🩺
                    </div>

                    <div>

                        <h4>
                            ${service.service}
                        </h4>

                        <p>
                            Pet: ${service.pet}
                        </p>

                        <p>
                            ${service.date}
                        </p>

                    </div>

                </div>

            `;

        }).join("");

}


/* =========================================
   APPOINTMENTS
========================================= */

function loadAppointments(data) {

    const container =
        document.getElementById(
            "appointmentHistory"
        );


    if (data.appointments.length === 0) {

        container.innerHTML = `

            <div class="empty-history">

                No appointments yet.

            </div>

        `;

        return;

    }


    container.innerHTML =
        data.appointments.map(function(appointment) {

            return `

                <div class="pet-card">

                    <div class="pet-avatar">
                        📅
                    </div>

                    <div>

                        <h4>
                            ${appointment.service}
                        </h4>

                        <p>
                            Pet: ${appointment.pet}
                        </p>

                        <p>
                            ${appointment.date}
                        </p>

                    </div>

                </div>

            `;

        }).join("");

}

async function loadOnlineAppointments() {

    const phone =
        localStorage.getItem("vetMedicsPhone");

    if (!phone) {
        return;
    }

    try {

        const response = await fetch(
            GOOGLE_SCRIPT_URL +
            "?action=getAppointments&phone=" +
            encodeURIComponent(phone)
        );

        const result = await response.json();

        if (!result.success) {
            return;
        }

        const data = getPetParentData();

        if (!data) {
            return;
        }

        data.appointments = result.appointments || [];

        savePetParentData(data);

        loadAppointments(data);

        document.getElementById(
            "totalAppointments"
        ).textContent =
            data.appointments.length;

    } catch (error) {

        console.error(
            "Appointment loading error:",
            error
        );

    }
}
